## PDF Encryption System
Pdf encrypting system. Get your pdf doc's encrypted/secured in a second.

##  Get Started
### Follow the following procedures to get started with the project:
      1) git clone https://github.com/Gicehajunior/pdf-encrypt/
      2) Open terminal, navigate to the project folder
      3) Using composer, Just do, composer install, that is, to install the dependencies. 
      4) Run the project by just doing, php -S localhost:8000
      5) On the browser, browse by doing localhost:8000
## Contribution
You are free on forking and requesting for changes.

## License
<a href="https://github.com/Gicehajunior/pdf-encrypt/blob/main/LICENSE">MIT</a>
