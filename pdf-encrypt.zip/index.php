<?php

require 'vendor/autoload.php';
require 'routes/web.php';